# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module for For Management of Events in School
# ----------------------------------------------------------

from . import models
from . import wizard
