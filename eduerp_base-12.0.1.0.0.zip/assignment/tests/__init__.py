# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to Assignment Management System
# ----------------------------------------------------------

from . import test_assignment
